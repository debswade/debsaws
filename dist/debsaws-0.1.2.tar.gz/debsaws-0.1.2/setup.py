# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['debsaws']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'debsaws',
    'version': '0.1.2',
    'description': '',
    'long_description': '',
    'author': 'debswade',
    'author_email': 'deborah.wade@hivehome.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/debswade/debsaws',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
